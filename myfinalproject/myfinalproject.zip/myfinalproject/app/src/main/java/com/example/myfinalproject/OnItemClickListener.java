package com.example.myfinalproject;

public interface OnItemClickListener {
    void getId(String id);
}
