package com.example.myfinalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminLogin extends AppCompatActivity {

    //declare every field
    EditText login_email, login_password;

    String email="arifullah9121@gmail.com";
    String password = "arif1234";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        //casting views or find View by childDataID
        login_email = (EditText) findViewById(R.id.login_email);
        login_password = (EditText) findViewById(R.id.login_password);




    }

    public void btn_admin_login(View view) {

        // From this field we get data and store in some string
        String Email = login_email.getText().toString();
        String Password = login_password.getText().toString();


        //validation of registration form
        if (Email.isEmpty()) {
            login_email.setError("Please Enter Email Address");

        } else if (Password.isEmpty()) {
            login_password.setError("Please Enter Password");

        } else {

           if((Email.matches(email)) && (Password.matches(password))) {
               startActivity(new Intent(getApplicationContext(),AdminActivity.class));

           }else {
               Toast.makeText(this, "invalid", Toast.LENGTH_SHORT).show();
           }
        }




    }


}
