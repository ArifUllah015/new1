package com.example.myfinalproject;

public class AdminHelper {
private String email,password;

public AdminHelper(){

}

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
