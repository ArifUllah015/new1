package com.example.myfinalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateVaccinator extends AppCompatActivity {

    //declare every field and button
    private EditText New_Email,New_Password;
    private Button btn_create;

    VaccinatorData  vaccinatordata;


    //create database reference
    DatabaseReference databaseReference;

    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_vaccinator);

        //casting views or find View by childDataID, data get which user put in the input field
        New_Email = (EditText)findViewById(R.id.new_email);
        New_Password = (EditText)findViewById(R.id.new_password);
        btn_create = (Button)findViewById(R.id.create);

        vaccinatordata = new VaccinatorData();

        //getInstance and create node in data base, give reference of helper class
        databaseReference = FirebaseDatabase.getInstance().getReference("VaccinatorData");


        btn_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Store the data in some strings, those data which we get from user input
                 final String email = New_Email.getText().toString();
                 final String password = New_Password.getText().toString();

                //validation of form

                //condition for user name
                if(email.isEmpty()){
                    New_Email.setError("Enter the user name");
                }else if(password.isEmpty()){
                    New_Password.setError("Enter password");
                }else {

                    vaccinatordata.setEmail(email);
                    vaccinatordata.setPassword(password);

                    databaseReference.push().setValue(vaccinatordata);
                    Toast.makeText(CreateVaccinator.this, "successfull", Toast.LENGTH_SHORT).show();


                }

            }
        });
    }
}
